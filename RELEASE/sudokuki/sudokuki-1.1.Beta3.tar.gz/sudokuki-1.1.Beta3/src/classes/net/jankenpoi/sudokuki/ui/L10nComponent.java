package net.jankenpoi.sudokuki.ui;

import java.util.Locale;

public interface L10nComponent {

	void setL10nMessages(Locale locale, String languageCode);
	
}
