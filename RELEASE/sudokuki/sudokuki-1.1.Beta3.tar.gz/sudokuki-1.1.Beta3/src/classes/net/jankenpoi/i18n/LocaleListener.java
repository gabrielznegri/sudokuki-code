package net.jankenpoi.i18n;

import java.util.Locale;

public interface LocaleListener {
	
	void onLocaleChanged(Locale newLocale);
	
}
