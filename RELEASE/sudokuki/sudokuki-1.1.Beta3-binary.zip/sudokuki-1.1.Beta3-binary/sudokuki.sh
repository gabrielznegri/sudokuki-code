java -Djava.library.path=./libs -jar sudokuki-1.1.Beta3.jar -ui Swing
