/*
 * Sudokuki - essential sudoku game
 * Copyright (C) 2007-2011 Sylvain Vedrenne
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package net.jankenpoi.sudokuki.ui.swing;

import static net.jankenpoi.i18n.I18n._;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileFilter;
import javax.swing.text.Utilities;

import net.jankenpoi.sudokuki.view.GridView;

@SuppressWarnings("serial")
public class SaveAsAction extends AbstractAction {

	private final GridView view;
	private final ActionsRepository actionsRepo;

	private final JFrame frame;
	
	SaveAsAction(JFrame frame, GridView view, ActionsRepository actions) {
		this.frame = frame;
		this.view = view;
		this.actionsRepo = actions;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		final JFileChooser fc = new JFileChooser();
		
		fc.setDialogTitle(_("Save as..."));
		fc.setAcceptAllFileFilterUsed(false);
		fc.setFileFilter(new FileFilter() {
			
			public String getExtension(File f) {
		        String ext = null;
		        String s = f.getName();
		        int i = s.lastIndexOf('.');

		        if (i > 0 &&  i < s.length() - 1) {
		            ext = s.substring(i+1).toLowerCase();
		        }
		        return ext;
		    }
			
			@Override
			public String getDescription() {
				// TODO Auto-generated method stub
				return _("Sudokuki grid files");
			}
			
			@Override
			public boolean accept(File f) {
				String extension = getExtension(f);
				System.out
						.println("SaveAsAction ext:"+extension+"|");
				if (f.isDirectory() || "skg".equals(extension)) {
					return true;
				}
				return false;
			}
		});
		int returnVal = fc.showOpenDialog(frame);
		
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			return;
		}
		File fileToSave = fc.getSelectedFile();
		if (fileToSave == null) {
			return;
		}
		fileToSave.delete();
		try {
			fileToSave.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileToSave);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (fos == null) {
			return;
		}
		
		for (int li=0; li<9; li++) {
			for (int co=0; co<9; co++) {
				try {
					fos.write(view.getValueAt(li, co));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		try {
			fos.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
